# 🌦️ Sistema de Gestión de Logs de Estaciones Meteorológicas

Sistema distribuido basado en microservicios para recolección, procesamiento y almacenamiento de datos de estaciones meteorológicas, usando RabbitMQ como broker de mensajería y PostgreSQL como base de datos.

---

## 📐 Arquitectura del Sistema

```
┌─────────────────────────────────────────────────────────────────────┐
│                     WEATHER STATION SYSTEM                          │
│                                                                     │
│  ┌──────────────┐      ┌──────────────────┐     ┌───────────────┐  │
│  │  PRODUCER    │      │    RABBITMQ       │     │   CONSUMER    │  │
│  │  (Python)    │─────▶│  Exchange: topic  │────▶│   (Python)    │  │
│  │              │ AMQP │  Queue: durable   │ ACK │               │  │
│  │ • Simula 5   │      │  Messages: persist│     │ • Valida datos│  │
│  │   estaciones │      │  DLQ: errores     │     │ • Persiste DB │  │
│  │ • Inyecta    │      │                   │     │ • Genera      │  │
│  │   anomalías  │      │  [Management UI]  │     │   alertas     │  │
│  └──────────────┘      │  puerto :15672    │     └──────┬────────┘  │
│                        └──────────────────┘            │           │
│                                                         │           │
│  ┌──────────────────────────────────────────────────────┼────────┐  │
│  │                   POSTGRESQL                         │        │  │
│  │                                                      ▼        │  │
│  │  weather_logs ◀─────────────────────────────── INSERT        │  │
│  │  weather_stations                                             │  │
│  │  weather_alerts                                               │  │
│  │  processing_errors                                            │  │
│  │  system_metrics                                               │  │
│  └──────────────────────────────────────────────────────────────┘  │
│                                                                     │
│  ┌─────────────┐    ┌──────────────┐    ┌─────────────────────┐    │
│  │ PROMETHEUS  │◀───│  PG Exporter │    │      GRAFANA        │    │
│  │  :9090      │◀───│  RMQ metrics │    │  Dashboards :3000   │    │
│  └─────────────┘    └──────────────┘    └─────────────────────┘    │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 🗂️ Estructura del Repositorio

```
weather-station-system/
├── docker-compose.yml          # Orquestación de todos los servicios
├── README.md                   # Esta documentación
│
├── producer/
│   ├── producer.py             # Simulador de estaciones meteorológicas
│   ├── Dockerfile
│   └── requirements.txt
│
├── consumer/
│   ├── consumer.py             # Procesador y persistidor de mensajes
│   ├── Dockerfile
│   └── requirements.txt
│
├── database/
│   └── init.sql                # Schema + datos iniciales de PostgreSQL
│
└── monitoring/
    ├── prometheus.yml           # Configuración de scraping
    └── rabbitmq-definitions.json # Pre-configuración de RabbitMQ
```

---

## 🚀 Inicio Rápido

### Prerrequisitos
- Docker Engine 24+ y Docker Compose 2.20+
- 4 GB RAM disponibles
- Puertos libres: 5432, 5672, 15672, 15692, 9090, 9187, 3000

### 1. Clonar y arrancar

```bash
git clone https://github.com/tu-usuario/weather-station-system.git
cd weather-station-system

# Arrancar todos los servicios
docker compose up -d

# Ver logs en tiempo real
docker compose logs -f

# Ver logs de un servicio específico
docker compose logs -f consumer
docker compose logs -f producer
```

### 2. Verificar estado de los servicios

```bash
# Estado de todos los contenedores
docker compose ps

# Debería mostrar todos los servicios como "healthy" o "running"
```

### 3. Acceder a las interfaces

| Servicio | URL | Credenciales |
|----------|-----|-------------|
| RabbitMQ Management | http://localhost:15672 | admin / admin_password |
| Grafana | http://localhost:3000 | admin / grafana_password |
| Prometheus | http://localhost:9090 | - |
| PostgreSQL | localhost:5432 | weather_user / weather_password |

---

## ⚙️ Configuración

### Variables de entorno del Productor

| Variable | Defecto | Descripción |
|----------|---------|-------------|
| `RABBITMQ_HOST` | rabbitmq | Host del broker |
| `RABBITMQ_PORT` | 5672 | Puerto AMQP |
| `RABBITMQ_USER` | admin | Usuario |
| `RABBITMQ_PASS` | admin_password | Contraseña |
| `EXCHANGE_NAME` | weather.exchange | Nombre del exchange |
| `ROUTING_KEY` | weather.readings | Routing key |
| `PUBLISH_INTERVAL` | 2.0 | Segundos entre publicaciones |
| `STATIONS_PER_BATCH` | 1 | Estaciones por ciclo |

### Variables de entorno del Consumidor

| Variable | Defecto | Descripción |
|----------|---------|-------------|
| `QUEUE_NAME` | weather.readings.queue | Cola a consumir |
| `PREFETCH_COUNT` | 1 | Mensajes simultáneos (QoS) |
| `PG_HOST` | postgres | Host de PostgreSQL |
| `PG_DB` | weather_db | Base de datos |
| `PG_USER` | weather_user | Usuario BD |
| `PG_PASS` | weather_password | Contraseña BD |

---

## 🗃️ Esquema de Base de Datos

### Tabla `weather_logs` (principal)

```sql
id               UUID PRIMARY KEY
station_id       VARCHAR(50) NOT NULL
station_name     VARCHAR(100)
latitude         DECIMAL(9,6)
longitude        DECIMAL(9,6)
timestamp        TIMESTAMPTZ      -- Hora de medición
received_at      TIMESTAMPTZ      -- Hora de procesamiento

-- Mediciones
temperature      DECIMAL(5,2)     -- °C: [-90, 60]
humidity         DECIMAL(5,2)     -- %: [0, 100]
pressure         DECIMAL(7,2)     -- hPa: [870, 1084]
wind_speed       DECIMAL(6,2)     -- km/h: [0, 400]
wind_direction   SMALLINT         -- °: [0, 360]
precipitation    DECIMAL(6,2)     -- mm: [0, 500]
uv_index         DECIMAL(4,1)     -- [0, 20]
visibility       DECIMAL(6,2)     -- km: [0, 100]

-- Procesamiento
raw_message      JSONB            -- Mensaje original completo
is_valid         BOOLEAN
validation_errors JSONB
processing_time_ms INTEGER
has_alert        BOOLEAN
alert_type       VARCHAR(50)
alert_severity   VARCHAR(20)      -- LOW | MEDIUM | HIGH | CRITICAL
```

### Vistas disponibles
- `v_station_stats` — Estadísticas agregadas por estación
- `v_active_alerts` — Alertas no reconocidas activas

---

## 📊 Flujo de Datos

```
1. PRODUCER genera WeatherReading (JSON)
        ↓
2. Publica a weather.exchange con routing_key="weather.readings"
   Mensajes marcados como PERSISTENT (delivery_mode=2)
        ↓
3. RabbitMQ enruta a weather.readings.queue (durable=True)
        ↓
4. CONSUMER recibe mensaje (prefetch_count=1)
        ↓
5. Deserializar JSON → WeatherReading dict
        ↓
6. WeatherValidator.validate() → errores de rango
        ↓
7. WeatherValidator.check_alerts() → alertas por umbrales
        ↓
8. DatabaseManager.save_log() → INSERT en weather_logs
   Si hay alertas → INSERT en weather_alerts
        ↓
9. basic_ack() si éxito | basic_nack(requeue=False) si fallo → DLQ
```

---

## 📏 Umbrales de Alertas

| Campo | Umbral HIGH | Umbral CRITICAL |
|-------|-------------|-----------------|
| `temperature` | ≥ 40°C o ≤ -20°C | ≥ 50°C |
| `wind_speed` | ≥ 80 km/h | ≥ 120 km/h |
| `precipitation` | ≥ 50 mm | - |

---

## 📈 Escalabilidad Horizontal

Para escalar consumidores en función de la carga:

```bash
# Arrancar 3 instancias del consumidor
docker compose up -d --scale consumer=3

# Ver instancias activas
docker compose ps consumer
```

Todos los consumidores comparten la misma cola. RabbitMQ distribuye
los mensajes en round-robin entre ellos.

---

## 🔍 Consultas de Ejemplo

```sql
-- Últimas 10 lecturas de todas las estaciones
SELECT station_id, station_name, timestamp, temperature, humidity
FROM weather_logs
ORDER BY received_at DESC
LIMIT 10;

-- Alertas activas (no reconocidas)
SELECT * FROM v_active_alerts;

-- Estadísticas por estación
SELECT * FROM v_station_stats ORDER BY total_logs DESC;

-- Mensajes inválidos
SELECT station_id, timestamp, validation_errors
FROM weather_logs
WHERE is_valid = FALSE
ORDER BY received_at DESC;

-- Temperatura promedio por día y estación (últimos 7 días)
SELECT
    station_id,
    DATE(timestamp) AS fecha,
    AVG(temperature) AS temp_promedio,
    MIN(temperature) AS temp_min,
    MAX(temperature) AS temp_max
FROM weather_logs
WHERE timestamp >= NOW() - INTERVAL '7 days'
GROUP BY station_id, DATE(timestamp)
ORDER BY fecha DESC, station_id;
```

---

## 🧪 Pruebas de Validación

El productor inyecta automáticamente anomalías cada 20 ciclos para probar las validaciones. Se puede verificar con:

```bash
# Ver logs del consumidor y buscar mensajes INVALID o ALERT
docker compose logs consumer | grep -E "INVALID|ALERT|SAVED"

# Ver errores de procesamiento en la BD
docker exec weather_postgres psql -U weather_user -d weather_db \
  -c "SELECT * FROM processing_errors ORDER BY occurred_at DESC LIMIT 5;"

# Ver alertas generadas
docker exec weather_postgres psql -U weather_user -d weather_db \
  -c "SELECT * FROM weather_alerts ORDER BY created_at DESC LIMIT 10;"
```

---

## 🧹 Mantenimiento

```bash
# Detener todos los servicios
docker compose down

# Detener y eliminar volúmenes (borra todos los datos)
docker compose down -v

# Limpiar logs de métricas antiguas (dentro del contenedor PostgreSQL)
docker exec weather_postgres psql -U weather_user -d weather_db \
  -c "SELECT cleanup_old_metrics(30);"

# Reconstruir imágenes tras cambios en el código
docker compose up -d --build producer consumer
```

---

## 🔐 Consideraciones de Seguridad

- Las credenciales de producción deben gestionarse con **Docker Secrets** o un vault (e.g., HashiCorp Vault).
- Habilitar **TLS** en RabbitMQ (`rabbitmq.conf` con `listeners.ssl.*`).
- PostgreSQL con **SSL habilitado** y conexiones desde red interna únicamente.
- Usar usuarios de BD con **mínimos privilegios** (ya definido el rol `weather_app`).

---

## 🔮 Extensiones Propuestas

1. **API REST** — FastAPI con endpoints para consultas históricas y exportación CSV/JSON.
2. **Servicio de Alertas** — Microservicio que consume `weather_alerts` y envía notificaciones (email, Slack, PagerDuty).
3. **Grafana Dashboards** — Pre-configurar dashboards con datasource de Prometheus + PostgreSQL.
4. **Autoscaling** — KEDA (Kubernetes Event-Driven Autoscaling) basado en profundidad de la cola.
5. **Stream Processing** — Integrar Apache Flink o Spark Streaming para análisis en tiempo real.

---

## 👥 Autor

Desarrollado como prototipo de caso de estudio para gestión de datos IoT con mensajería asíncrona.

**Stack técnico**: Python 3.13 · pika 1.3 · psycopg2 2.9 · RabbitMQ 3.13 · PostgreSQL 16 · Prometheus · Grafana · Docker Compose
